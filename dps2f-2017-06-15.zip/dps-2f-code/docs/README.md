> This project is work in progress.

# Shibboleth IDP 3.3, e-mail code based 2nd factor.
This is an e-mail code second factor authentication flow for Shibboleth Identity Provider v3.3.x. 
It was derived from the [G2F Flow](https://github.com/gtkrug/shib-g2f).   You can follow the install instructions for G2F...

## Notes
Tested with Shibboleth Identity Provider 3.3.x and Google Chrome 57.x and Firefox 53

## Requirements
* [Shibboleth Identity Provider 3.3.x](http://shibboleth.net/downloads/identity-provider/latest/)
* Java 8

## Installation
TBD.

